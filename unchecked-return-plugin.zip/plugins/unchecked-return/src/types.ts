/**
 * LOCAL MIRRORS of the types the scanner exposes.
 *
 * TODO(integration): the real `IRulePlugin`, `Finding` and `SourceFile`
 * shapes live in `@veridion/scanner-types`. Replace this file with imports
 * from that package and adapt `UncheckedReturnPlugin` to the real signature.
 * The detection logic in analyzer.ts does not depend on any of these.
 */

export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info';

export interface SourceFile {
  path: string;
  content: string;
}

export interface Finding {
  ruleId: string;
  title: string;
  description: string;
  severity: Severity;
  file: string;
  line: number;
  column: number;
  snippet: string;
  recommendation: string;
  references: string[];
}

export interface IRulePlugin {
  readonly id: string;
  readonly name: string;
  readonly version: string;
  readonly description: string;
  analyze(file: SourceFile): Finding[] | Promise<Finding[]>;
}

export type LowLevelCall = 'call' | 'send' | 'delegatecall' | 'transfer';

export type IssueReason = 'discarded' | 'ignored-tuple' | 'unchecked-variable';

export interface Issue {
  method: LowLevelCall;
  reason: IssueReason;
  /** Name of the variable that captured the result but was never checked. */
  variable?: string;
  /** Offset of the start of the call expression in the original source. */
  index: number;
  line: number;
  column: number;
  snippet: string;
}

export interface AnalyzerOptions {
  /**
   * Also flag `.transfer(...)`. Off by default: `address.transfer` reverts on
   * failure and returns nothing, but ERC-20 `token.transfer` returns a bool.
   */
  includeTransfer?: boolean;
}
