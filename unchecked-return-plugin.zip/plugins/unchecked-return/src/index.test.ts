import { describe, expect, it } from 'vitest';
import UncheckedReturnPlugin, { RULE_ID, analyze, sanitize } from './index';

const wrap = (body: string): string => `
contract C {
  function f(address payable a, uint256 x) external {
    ${body}
  }
}`;

const flagged = (body: string, opts = {}) => analyze(wrap(body), opts);

describe('unchecked results are flagged', () => {
  it('discarded .call', () => {
    const r = flagged('a.call{value: x}("");');
    expect(r).toHaveLength(1);
    expect(r[0]).toMatchObject({ method: 'call', reason: 'discarded' });
  });

  it('discarded .send', () => {
    expect(flagged('a.send(x);')[0]).toMatchObject({ method: 'send', reason: 'discarded' });
  });

  it('discarded .delegatecall', () => {
    expect(flagged('a.delegatecall(msg.data);')[0]).toMatchObject({
      method: 'delegatecall',
      reason: 'discarded',
    });
  });

  it('legacy .call.value(...)() syntax', () => {
    expect(flagged('a.call.value(x)("");')).toHaveLength(1);
  });

  it('receivers such as msg.sender, payable(...) and mapping lookups', () => {
    expect(flagged('msg.sender.call{value: x}("");')).toHaveLength(1);
    expect(flagged('payable(address(this)).send(x);')).toHaveLength(1);
    expect(flagged('owners[0].call("");')).toHaveLength(1);
    expect(flagged('m[a][1].send(x);')).toHaveLength(1);
    expect(flagged('getRecipient(x)[0].send(x);')).toHaveLength(1);
  });

  it('call as the body of an unbraced if / else', () => {
    expect(flagged('if (x > 0) a.send(x);')).toHaveLength(1);
    expect(flagged('if (x > 0) { } else a.send(x);')).toHaveLength(1);
  });

  it('tuple without a success name', () => {
    expect(flagged('(, bytes memory d) = a.call("");')[0].reason).toBe('ignored-tuple');
    expect(flagged('(bool, ) = a.call("");')[0].reason).toBe('ignored-tuple');
  });

  it('success captured but never checked', () => {
    const r = flagged('(bool ok, ) = a.call("");\n    x = 1;');
    expect(r[0]).toMatchObject({ reason: 'unchecked-variable', variable: 'ok' });
  });

  it('success only logged or reassigned is not a check', () => {
    expect(flagged('bool ok = a.send(x);\n    emit E(ok);')).toHaveLength(1);
    expect(flagged('bool ok = a.send(x);\n    ok = true;')).toHaveLength(1);
  });

  it('flags every unchecked call and reports positions', () => {
    const r = flagged('a.send(1);\n    a.call("");');
    expect(r).toHaveLength(2);
    expect(r[0].line).toBeLessThan(r[1].line);
    expect(r[0].column).toBeGreaterThan(0);
    expect(r[0].snippet).toBe('a.send(1);');
  });
});

describe('checked results are not flagged', () => {
  it.each([
    'require(a.send(x));',
    'assert(a.send(x));',
    'if (!a.send(x)) revert();',
    'if (a.send(x)) { x = 1; }',
    'require(a.send(x) && x > 0);',
    'return;',
  ])('inline: %s', (body) => {
    expect(flagged(body)).toHaveLength(0);
  });

  it('success checked with require', () => {
    expect(flagged('(bool ok, ) = a.call("");\n    require(ok, "fail");')).toHaveLength(0);
  });

  it('success checked with if / revert, including else-if and ternary', () => {
    expect(flagged('(bool ok, ) = a.call("");\n    if (!ok) { revert(); }')).toHaveLength(0);
    expect(
      flagged('bool ok = a.send(x);\n    if (x == 0) { x = 1; } else if (!ok) { revert(); }'),
    ).toHaveLength(0);
    expect(flagged('bool ok = a.send(x);\n    x = ok ? 1 : 2;')).toHaveLength(0);
  });

  it('success returned or assigned to an existing variable then asserted', () => {
    expect(flagged('(bool ok, ) = a.call("");\n    assert(ok);')).toHaveLength(0);
    expect(flagged('bool ok;\n    ok = a.send(x);\n    require(ok);')).toHaveLength(0);
  });

  it('returned directly', () => {
    expect(
      analyze('contract C { function f(address a) external returns (bool) { return a.send(1); } }'),
    ).toHaveLength(0);
  });

  it('comparison and argument usage', () => {
    expect(flagged('require(a.send(x) == true);')).toHaveLength(0);
    expect(flagged('emit E(a.send(x));')).toHaveLength(0);
  });

  it('unrelated member names and function declarations', () => {
    expect(flagged('a.callback();')).toHaveLength(0);
    expect(flagged('a.sendValue(x);')).toHaveLength(0);
    expect(flagged('a.transferFrom(a, a, x);')).toHaveLength(0);
    expect(analyze('interface I { function send(address to) external; }')).toHaveLength(0);
  });

  it('property access without a call', () => {
    expect(flagged('x = a.call;')).toHaveLength(0);
    expect(flagged('x = a.call.value;')).toHaveLength(0);
  });

  it('ignores comments and string literals', () => {
    expect(flagged('// a.send(x);')).toHaveLength(0);
    expect(flagged('/* a.call(""); */')).toHaveLength(0);
    expect(flagged('string memory s = "a.send(1);";')).toHaveLength(0);
  });
});

describe('transfer handling', () => {
  it('is ignored by default', () => {
    expect(flagged('a.transfer(x);')).toHaveLength(0);
  });

  it('can be enabled for ERC-20 style transfers', () => {
    expect(flagged('token.transfer(a, x);', { includeTransfer: true })[0].method).toBe('transfer');
    expect(flagged('require(token.transfer(a, x));', { includeTransfer: true })).toHaveLength(0);
  });
});

describe('sanitize', () => {
  it('keeps offsets and newlines intact', () => {
    const src = 'a // c\n/* x\ny */ "s\\"t" \'q\'';
    const out = sanitize(src);
    expect(out).toHaveLength(src.length);
    expect(out.split('\n')).toHaveLength(src.split('\n').length);
    expect(out).not.toContain('c\n');
  });

  it('handles unterminated comments and strings', () => {
    expect(sanitize('/* open')).toHaveLength(7);
    expect(sanitize('"open\nnext')).toHaveLength(10);
  });
});

describe('UncheckedReturnPlugin', () => {
  const plugin = new UncheckedReturnPlugin();
  const file = { path: 'contracts/Vault.sol', content: wrap('a.call{value: x}("");') };

  it('exposes plugin metadata', () => {
    expect(plugin.id).toBe(RULE_ID);
    expect(plugin.name).toBeTruthy();
    expect(plugin.version).toMatch(/^\d+\.\d+\.\d+$/);
    expect(plugin.description).toContain('SWC-104');
  });

  it('produces findings with a require(success) recommendation', () => {
    const findings = plugin.analyze(file);
    expect(findings).toHaveLength(1);
    expect(findings[0]).toMatchObject({
      ruleId: RULE_ID,
      severity: 'medium',
      file: 'contracts/Vault.sol',
    });
    expect(findings[0].recommendation).toContain('require(success');
    expect(findings[0].references.length).toBeGreaterThan(0);
  });

  it.each([
    ['a.send(x);', 'send'],
    ['a.delegatecall("");', 'delegatecall'],
    ['(, bytes memory d) = a.call("");', 'call'],
    ['bool ok = a.send(x);', 'send'],
  ])('describes %s', (body, method) => {
    const [f] = plugin.analyze({ path: 'x.sol', content: wrap(body) });
    expect(f.title).toContain(method);
    expect(f.description.length).toBeGreaterThan(10);
    expect(f.recommendation).toContain('require(');
  });

  it('describes transfer findings when enabled', () => {
    const p = new UncheckedReturnPlugin({ includeTransfer: true });
    const [f] = p.analyze({ path: 'x.sol', content: wrap('token.transfer(a, x);') });
    expect(f.recommendation).toContain('token.transfer');
  });

  it('returns nothing for clean contracts', () => {
    const clean = { path: 'x.sol', content: wrap('(bool ok, ) = a.call("");\n    require(ok);') };
    expect(plugin.analyze(clean)).toEqual([]);
  });
});
