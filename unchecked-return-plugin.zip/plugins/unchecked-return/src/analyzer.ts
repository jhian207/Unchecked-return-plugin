import type { AnalyzerOptions, Issue, IssueReason, LowLevelCall } from './types.js';

const WS = /\s/;
const IDENT = /[A-Za-z0-9_$]/;

const isIdent = (ch: string | undefined): boolean => !!ch && IDENT.test(ch);

/**
 * Blank out comments and string literals while preserving every offset and
 * newline, so positions found in the result map 1:1 onto the original source.
 */
export function sanitize(src: string): string {
  let out = '';
  let i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    const d = src[i + 1];
    if (c === '/' && d === '/') {
      while (i < n && src[i] !== '\n') {
        out += ' ';
        i++;
      }
      continue;
    }
    if (c === '/' && d === '*') {
      out += '  ';
      i += 2;
      while (i < n && !(src[i] === '*' && src[i + 1] === '/')) {
        out += src[i] === '\n' ? '\n' : ' ';
        i++;
      }
      if (i < n) {
        out += '  ';
        i += 2;
      }
      continue;
    }
    if (c === '"' || c === "'") {
      out += c;
      i++;
      while (i < n && src[i] !== c && src[i] !== '\n') {
        if (src[i] === '\\' && i + 1 < n) {
          out += src[i + 1] === '\n' ? ' \n' : '  ';
          i += 2;
          continue;
        }
        out += ' ';
        i++;
      }
      if (i < n && src[i] === c) {
        out += c;
        i++;
      }
      continue;
    }
    out += c;
    i++;
  }
  return out;
}

function prevNonWs(s: string, i: number): number {
  let k = i - 1;
  while (k >= 0 && WS.test(s[k])) k--;
  return k;
}

function nextNonWs(s: string, i: number): number {
  let k = i;
  while (k < s.length && WS.test(s[k])) k++;
  return k;
}

function skipBalancedForward(s: string, i: number, open: string, close: string): number {
  let depth = 0;
  for (let j = i; j < s.length; j++) {
    if (s[j] === open) depth++;
    else if (s[j] === close) {
      depth--;
      if (depth === 0) return j + 1;
    }
  }
  return -1;
}

function skipBalancedBackward(s: string, i: number, close: string, open: string): number {
  let depth = 0;
  for (let j = i; j >= 0; j--) {
    if (s[j] === close) depth++;
    else if (s[j] === open) {
      depth--;
      if (depth === 0) return j;
    }
  }
  return -1;
}

function wordEndingAt(s: string, k: number): string {
  if (k < 0 || !isIdent(s[k])) return '';
  let m = k;
  while (m > 0 && isIdent(s[m - 1])) m--;
  return s.slice(m, k + 1);
}

function lastBoundary(s: string, idx: number): number {
  for (let j = idx - 1; j >= 0; j--) {
    if (s[j] === ';' || s[j] === '{' || s[j] === '}') return j;
  }
  return -1;
}

/**
 * Given the index just after `.call` / `.send` / ..., returns the index just
 * after the closing paren of the argument list, or -1 if this is not a call.
 * Handles `{value: x}` options and the legacy `.value(x)` / `.gas(x)` chain.
 */
function parseCallEnd(s: string, pos: number): number {
  let i = pos;
  for (;;) {
    i = nextNonWs(s, i);
    if (s[i] === '{') {
      i = skipBalancedForward(s, i, '{', '}');
      if (i < 0) return -1;
      continue;
    }
    if (s[i] === '.') {
      const re = /\.\s*(?:value|gas)\b/y;
      re.lastIndex = i;
      const m = re.exec(s);
      if (!m) return -1;
      i = nextNonWs(s, i + m[0].length);
      if (s[i] !== '(') return -1;
      i = skipBalancedForward(s, i, '(', ')');
      if (i < 0) return -1;
      continue;
    }
    if (s[i] === '(') return skipBalancedForward(s, i, '(', ')');
    return -1;
  }
}

/** Walks backwards over `a.b[i].c(x).d` style receivers to find where they start. */
function receiverStart(s: string, dotIdx: number): number {
  let end = dotIdx;
  for (;;) {
    const k = prevNonWs(s, end);
    if (k < 0) return end;
    const ch = s[k];
    if (ch === ')' || ch === ']') {
      // consume a primary such as `f(x)`, `a[i]`, `a[i][j]` or `f(x)[i]`
      let cur = k;
      for (;;) {
        const c = s[cur];
        const open = skipBalancedBackward(s, cur, c, c === ')' ? '(' : '[');
        if (open < 0) return end;
        end = open;
        const before = end - 1;
        if (before >= 0 && (s[before] === ']' || s[before] === ')')) {
          cur = before;
          continue;
        }
        while (end > 0 && isIdent(s[end - 1])) end--;
        break;
      }
    } else if (isIdent(ch)) {
      let m = k;
      while (m > 0 && isIdent(s[m - 1])) m--;
      end = m;
    } else {
      return end;
    }
    const p = prevNonWs(s, end);
    if (p >= 0 && s[p] === '.') {
      end = p;
      continue;
    }
    return end;
  }
}

const CHECK_PREFIX = /^\s*(?:else\s+)?(?:require|assert|if|while|return)\b/;

/** True if `name` is used in a condition/require/assert/return after `from`, within the enclosing block. */
function isChecked(s: string, name: string, from: number): boolean {
  let depth = 0;
  let end = s.length;
  for (let i = from; i < s.length; i++) {
    if (s[i] === '{') depth++;
    else if (s[i] === '}') {
      if (depth === 0) {
        end = i;
        break;
      }
      depth--;
    }
  }
  const re = new RegExp(`(?<![A-Za-z0-9_$.])${name.replace(/\$/g, '\\$')}(?![A-Za-z0-9_$])`, 'g');
  re.lastIndex = from;
  for (let m = re.exec(s); m && m.index < end; m = re.exec(s)) {
    const after = s.slice(m.index + name.length, end);
    if (/^\s*=(?!=)/.test(after)) continue; // plain reassignment, not a read
    if (/^\s*\?/.test(after)) return true; // ternary condition
    const b = lastBoundary(s, m.index);
    if (CHECK_PREFIX.test(s.slice(b + 1, m.index))) return true;
  }
  return false;
}

function classifyAssignment(
  s: string,
  eq: number,
  callEnd: number,
): { reason: IssueReason; variable?: string } | null {
  const b = lastBoundary(s, eq);
  const lhs = s.slice(b + 1, eq).trim();
  let name: string | undefined;

  const tuple = /\(\s*(?:bool\s+([A-Za-z_$][\w$]*)|([A-Za-z_$][\w$]*))?\s*,[^)]*\)$/.exec(lhs);
  if (tuple) {
    name = tuple[1] ?? (tuple[2] && tuple[2] !== 'bool' ? tuple[2] : undefined);
  } else {
    const single = /(?:\bbool\s+)?([A-Za-z_$][\w$]*)\s*$/.exec(lhs);
    name = single && single[1] !== 'bool' ? single[1] : undefined;
  }

  if (!name) return { reason: 'ignored-tuple' };

  let semi = s.indexOf(';', callEnd);
  if (semi < 0) semi = callEnd - 1;
  if (isChecked(s, name, semi + 1)) return null;
  return { reason: 'unchecked-variable', variable: name };
}

function classify(
  s: string,
  start: number,
  callEnd: number,
): { reason: IssueReason; variable?: string } | null {
  const k = prevNonWs(s, start);
  const prevCh = k >= 0 ? s[k] : ';';
  const prevWord = wordEndingAt(s, k);

  if (prevWord === 'return') return null;

  if (prevCh === '=') {
    if (k > 0 && '=!<>'.includes(s[k - 1])) return null; // comparison, value is used
    return classifyAssignment(s, k, callEnd);
  }

  const statementPosition =
    ';{}'.includes(prevCh) || prevCh === ')' || prevWord === 'else' || prevWord === 'do';
  if (!statementPosition) return null; // used inline: require(x.send()), a && x.send(), ...

  const after = nextNonWs(s, callEnd);
  if (s[after] !== ';') return null;
  return { reason: 'discarded' };
}

function lineStartsOf(src: string): number[] {
  const starts = [0];
  for (let i = 0; i < src.length; i++) {
    if (src[i] === '\n') starts.push(i + 1);
  }
  return starts;
}

function locate(starts: number[], index: number): { line: number; column: number } {
  let lo = 0;
  let hi = starts.length - 1;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (starts[mid] <= index) lo = mid;
    else hi = mid - 1;
  }
  return { line: lo + 1, column: index - starts[lo] + 1 };
}

export function analyze(source: string, options: AnalyzerOptions = {}): Issue[] {
  const s = sanitize(source);
  const methods: LowLevelCall[] = ['call', 'send', 'delegatecall'];
  if (options.includeTransfer) methods.push('transfer');

  const re = new RegExp(`\\.\\s*(${methods.join('|')})\\b`, 'g');
  const starts = lineStartsOf(source);
  const lines = source.split('\n');
  const issues: Issue[] = [];

  for (let m = re.exec(s); m; m = re.exec(s)) {
    const callEnd = parseCallEnd(s, m.index + m[0].length);
    if (callEnd < 0) continue;

    const start = receiverStart(s, m.index);
    const verdict = classify(s, start, callEnd);
    if (!verdict) continue;

    const { line, column } = locate(starts, start);
    issues.push({
      method: m[1] as LowLevelCall,
      reason: verdict.reason,
      variable: verdict.variable,
      index: start,
      line,
      column,
      snippet: (lines[line - 1] ?? '').trim(),
    });
  }
  return issues;
}
