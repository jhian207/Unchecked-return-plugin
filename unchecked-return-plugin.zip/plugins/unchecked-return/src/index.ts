import { analyze } from './analyzer.js';
import type {
  AnalyzerOptions,
  Finding,
  IRulePlugin,
  Issue,
  LowLevelCall,
  SourceFile,
} from './types.js';

export { analyze, sanitize } from './analyzer.js';
export type { AnalyzerOptions, Finding, IRulePlugin, Issue, SourceFile } from './types.js';

export const RULE_ID = 'unchecked-return';

const REFERENCES = [
  'https://swcregistry.io/docs/SWC-104',
  'https://cwe.mitre.org/data/definitions/252.html',
];

const FIXES: Record<LowLevelCall, string> = {
  call: '(bool success, ) = target.call{value: amount}("");\nrequire(success, "Low-level call failed");',
  delegatecall:
    '(bool success, ) = target.delegatecall(data);\nrequire(success, "Delegatecall failed");',
  send: 'bool success = recipient.send(amount);\nrequire(success, "Send failed");',
  transfer: 'require(token.transfer(to, amount), "Transfer failed");',
};

function describe(issue: Issue): string {
  const call = `.${issue.method}()`;
  switch (issue.reason) {
    case 'discarded':
      return `The return value of ${call} is discarded. If the call fails, execution continues silently.`;
    case 'ignored-tuple':
      return `The success flag returned by ${call} is not captured, so a failed call goes unnoticed.`;
    case 'unchecked-variable':
      return `The result of ${call} is stored in "${issue.variable}" but never checked with require, assert, if or return.`;
  }
}

export class UncheckedReturnPlugin implements IRulePlugin {
  readonly id = RULE_ID;
  readonly name = 'Unchecked Return Value';
  readonly version = '0.1.0';
  readonly description =
    'Detects low-level calls (.call, .send, .delegatecall) whose return value is not checked (SWC-104).';

  constructor(private readonly options: AnalyzerOptions = {}) {}

  analyze(file: SourceFile): Finding[] {
    return analyze(file.content, this.options).map((issue) => ({
      ruleId: RULE_ID,
      title: `Unchecked return value of .${issue.method}()`,
      description: describe(issue),
      severity: 'medium',
      file: file.path,
      line: issue.line,
      column: issue.column,
      snippet: issue.snippet,
      recommendation: `Capture the result and revert on failure:\n${FIXES[issue.method]}`,
      references: REFERENCES,
    }));
  }
}

export default UncheckedReturnPlugin;
