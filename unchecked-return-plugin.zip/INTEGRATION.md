# Integration notes — unchecked-return plugin (issue #16)

The code in `plugins/unchecked-return/` was written WITHOUT access to the repo's
`@veridion/scanner-types` package or `plugin-registry.ts` (neither was reachable),
so two things need a quick manual step:

1. **Real `IRulePlugin` / `Finding` types.** `src/types.ts` holds local stand-ins.
   Replace them with imports from `@veridion/scanner-types`, add that package as a
   `workspace:*` dependency, and adjust `UncheckedReturnPlugin.analyze()` (in
   `src/index.ts`) to the real method name/signature and finding shape.
   `src/analyzer.ts` is independent of all that and needs no change.

2. **Registry.** In `packages/scanner-core/src/plugin-registry.ts` add:

   ```ts
   import { UncheckedReturnPlugin } from '@veridion/plugin-unchecked-return';
   // ...inside registerDefaultPlugins() / createDefaultRegistry():
   registry.register(new UncheckedReturnPlugin());
   ```

   (match whatever registration call the other plugins use there).

## Behaviour
- Flags `.call`, `.send`, `.delegatecall` whose result is discarded, whose success
  flag isn't captured, or is captured but never used in require/assert/if/while/
  return/ternary.
- `.transfer` is skipped by default (it reverts on failure); `new UncheckedReturnPlugin({ includeTransfer: true })`
  flags it for ERC-20-style bool-returning transfers.
- Text-based (comments/strings stripped), not AST-based, so it can't know a
  receiver's type: a custom contract's own `.call()` method may be flagged.

## Verification done here
- `tsc --noEmit` passes.
- All 36 tests pass via a small vitest-compatible shim (vitest itself and the
  coverage plugin couldn't be installed offline). Run `pnpm test:coverage` in the
  repo to confirm the 80% thresholds.
